#ifdef LEXICAL_H
#define LEXICAL_H

void analyze(char input[]);


int isKeyword(char word[]);
int isDataType(char word[]);
int isBinary(char word[]);
int isOctal(char word[]);
int isHexadecimal(char word[]);

#endif
