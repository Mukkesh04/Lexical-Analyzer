#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "lexical.h"


int isKeyword(char word[])
{
    char *keywords[] =
    {
        "int", "float", "char", "double",
        "if", "else", "while", "for",
        "return", "void"
    };

    int i;

    for (i = 0; i < 10; i++)
    {
        if (strcmp(word, keywords[i]) == 0)
        {
            return 1;
        }
    }

    return 0;
}


int isDataType(char word[])
{
    if (strcmp(word, "int") == 0 ||
        strcmp(word, "float") == 0 ||
        strcmp(word, "char") == 0 ||
        strcmp(word, "double") == 0)
    {
        return 1;
    }

    return 0;
}


int isBinary(char word[])
{
    int i = 2;

    if (word[i] == '\0')
    {
        return 0;
    }

    while (word[i] != '\0')
    {
        if (word[i] != '0' && word[i] != '1')
        {
            return 0;
        }

        i++;
    }

    return 1;
}


int isOctal(char word[])
{
    int i = 1;

    if (word[i] == '\0')
    {
        return 1;
    }

    while (word[i] != '\0')
    {
        if (word[i] < '0' || word[i] > '7')
        {
            return 0;
        }

        i++;
    }

    return 1;
}


int isHexadecimal(char word[])
{
    int i = 2;

    if (word[i] == '\0')
    {
        return 0;
    }

    while (word[i] != '\0')
    {
        if (!isdigit(word[i]) &&
            !(word[i] >= 'A' && word[i] <= 'F') &&
            !(word[i] >= 'a' && word[i] <= 'f'))
        {
            return 0;
        }

        i++;
    }

    return 1;
}


void analyze(char input[])
{
    char word[100];

    int i = 0;
    int j;

    int line = 1;

    int curlyCount = 0;
    int parenthesisCount = 0;

    int squareCount = 0;
    int squareLine[100];
    int squareTop = -1;

    int expectIdentifier = 0;


    while (input[i] != '\0')
    {
        
        if (input[i] == '\n')
        {
            line++;
            i++;
        }


        else if (input[i] == ' ' || input[i] == '\t')
        {
            i++;
        }


      
        else if (isalpha(input[i]) || input[i] == '_')
        {
            j = 0;

            while (isalnum(input[i]) || input[i] == '_')
            {
                word[j] = input[i];
                j++;
                i++;
            }

            word[j] = '\0';

            if (isKeyword(word))
            {
                printf("%s : Keyword\n", word);

                if (isDataType(word))
                {
                    expectIdentifier = 1;
                }
            }
            else
            {
                printf("%s : Identifier\n", word);
                expectIdentifier = 0;
            }
        }


        
        else if (isdigit(input[i]))
        {
            j = 0;

            while (isalnum(input[i]))
            {
                word[j] = input[i];
                j++;
                i++;
            }

            word[j] = '\0';


            
            if (word[0] == '0' &&
                (word[1] == 'b' || word[1] == 'B'))
            {
                if (isBinary(word))
                {
                    printf("%s : Constant\n", word);
                }
                else
                {
                    printf("%s : Error - Invalid Binary Number\n",
                           word);
                }

                expectIdentifier = 0;
            }


            
            else if (word[0] == '0' &&
                     (word[1] == 'x' || word[1] == 'X'))
            {
                if (isHexadecimal(word))
                {
                    printf("%s : Constant\n", word);
                }
                else
                {
                    printf("%s : Error - Invalid Hexadecimal Number\n",
                           word);
                }

                expectIdentifier = 0;
            }


            
            else if (isalpha(word[j - 1]))
            {
                if (expectIdentifier)
                {
                    printf("%s : Error - Variable should not start with a number\n",
                           word);
                }
                else
                {
                    printf("%s : Error - Decimal number should not contain alphabets\n",
                           word);
                }

                expectIdentifier = 0;
            }


            
            else if (word[0] == '0' && word[1] != '\0')
            {
                if (isOctal(word))
                {
                    printf("%s : Constant\n", word);
                }
                else
                {
                    printf("%s : Error - Invalid Octal Number\n",
                           word);
                }

                expectIdentifier = 0;
            }


            
            else
            {
                printf("%s : Constant\n", word);

                expectIdentifier = 0;
            }
        }


        
        else if (input[i] == '<' ||
                 input[i] == '>' ||
                 input[i] == '!' ||
                 input[i] == '=')
        {
            if (input[i + 1] == '=')
            {
                printf("%c%c : Relational Operator\n",
                       input[i], input[i + 1]);

                i += 2;
            }
            else if (input[i] == '<' || input[i] == '>')
            {
                printf("%c : Relational Operator\n",
                       input[i]);

                i++;
            }
            else if (input[i] == '=')
            {
                printf("%c : Assignment operator\n",
                       input[i]);

                i++;
            }
            else
            {
                printf("%c : Operator\n", input[i]);

                i++;
            }
        }


      
        else if (input[i] == '+' ||
                 input[i] == '-' ||
                 input[i] == '*' ||
                 input[i] == '/' ||
                 input[i] == '%')
        {
            printf("%c : Operator\n", input[i]);

            i++;
        }


        
        else if (input[i] == '{')
        {
            printf("{ : Special character\n");

            curlyCount++;
            i++;
        }

        else if (input[i] == '}')
        {
            printf("} : Special character\n");

            if (curlyCount == 0)
            {
                printf("Error : Closing curly brace without opening brace at line %d\n",
                       line);
            }
            else
            {
                curlyCount--;
            }

            i++;
        }


       
        else if (input[i] == '(')
        {
            printf("( : Special character\n");

            parenthesisCount++;
            i++;
        }

        else if (input[i] == ')')
        {
            printf(") : Special character\n");

            if (parenthesisCount == 0)
            {
                printf("Error : Closing parenthesis without opening parenthesis at line %d\n",
                       line);
            }
            else
            {
                parenthesisCount--;
            }

            i++;
        }


        
        else if (input[i] == '[')
        {
            printf("[ : Special character\n");

            squareCount++;
            squareTop++;

            squareLine[squareTop] = line;

            i++;
        }

        else if (input[i] == ']')
        {
            printf("] : Special character\n");

            if (squareCount == 0)
            {
                printf("Error : Closing square bracket without opening bracket at line %d\n",
                       line);
            }
            else
            {
                if (squareLine[squareTop] != line)
                {
                    printf("Error : Square brackets should be opened and closed on the same line\n");
                }

                squareCount--;
                squareTop--;
            }

            i++;
        }


        
        else if (input[i] == ';' || input[i] == ',')
        {
            printf("%c : Special character\n", input[i]);

            if (input[i] == ';')
            {
                expectIdentifier = 0;
            }

            i++;
        }


        
        else
        {
            printf("%c : Unknown\n", input[i]);

            i++;
        }
    }


    
    if (curlyCount > 0)
    {
        printf("\nError : Curly braces are not properly closed\n");
    }


    
    if (parenthesisCount > 0)
    {
        printf("\nError : Parentheses are not properly closed\n");
    }


    
    if (squareCount > 0)
    {
        printf("\nError : Square brackets are not properly closed\n");
    }
}







