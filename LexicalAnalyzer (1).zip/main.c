#include <stdio.h>
#include "lexical.h"

int main()
{
	char input[1000];
	int i = 0;
	int ch;
	printf("Enter the source code:\n ");
	printf("Press Ctrl + D after entering the input\n\n");
	
	while ((ch = getchar()) != EOF && i < 999)
	{
		input[i] = ch;
		i++;
	}
	input[i] = '\0';
	printf("\nLexical analysis: \n\n");
	analyze(input);
	return 0;
}
